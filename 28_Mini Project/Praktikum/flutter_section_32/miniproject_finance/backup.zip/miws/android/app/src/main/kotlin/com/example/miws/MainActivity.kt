package com.example.miws

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
